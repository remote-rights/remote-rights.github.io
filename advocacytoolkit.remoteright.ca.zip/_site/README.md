# Remote Rights Advocacy Toolkit

## Development

```
bundle install
bundle exec jekyll serve -l
```

## Production

- The master branch is automatically published to remote-rights.github.io.
- To build HTML to be hosted elsewhere, run `bundle exec jekyl build`. Note that you will have to change the URL in the `_config.yml` file if you are hosting the site in another location.
